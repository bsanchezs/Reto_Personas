import Foundation

enum Sexo{
    case M
    case F
}

// Obtener fecha y hora actual en el formato dd/mm/yyyy
let fechaHoraActual = Date()
let dateFormatter = DateFormatter()
dateFormatter.dateFormat = "dd/MM/yyyy"
let hoy = dateFormatter.string(from: fechaHoraActual)
//print("hoy es: \(hoy)")

// Funcion para descomponer el dia, hora y año segun una fecha y guardarlo en un array
func obtenerDiaMesAnio(fecha: String) -> [Int] {
    
    var arrFecha: [Int] = [];
    
    // Se obtienen los indices donde estan el primer y ultimo caracter de los dias, meses y años para volverlos enteros y usarlos para la edad
    let inicioDia = fecha.index(fecha.startIndex, offsetBy: 0)
    let finDia = fecha.index(fecha.startIndex, offsetBy: 2)
    let dia = Int(fecha[inicioDia..<finDia])
    
    arrFecha.append(dia!);

    let inicioMes = fecha.index(fecha.startIndex, offsetBy: 3)
    let finMes = fecha.index(fecha.startIndex, offsetBy: 5)
    let mes = Int(fecha[inicioMes..<finMes])

    arrFecha.append(mes!);
    
    let inicioAnio = fecha.index(fecha.startIndex, offsetBy: 6)
    let finAnio = fecha.index(fecha.startIndex, offsetBy: hoy.count)
    let anio = Int(fecha[inicioAnio..<finAnio])
    
    arrFecha.append(anio!)
    
    return arrFecha;
    
}

// Obtenemos el dia, mes y año de la fecha actual y los almacenamos en un array para despues ponerlo en variables separadas
let arrFechaHoy: [Int] = obtenerDiaMesAnio(fecha: hoy)
let diaHoy = arrFechaHoy[0]
let mesHoy = arrFechaHoy[1]
let anioHoy = arrFechaHoy[2]



// Struct Persona
struct Persona{
    
    let nombres: String
    let apellidoPaterno: String
    let apellidoMaterno: String
    let fechaNacimiento: String
    let DNI: String
    let sexo: Sexo
    let cantidadHermanos: Int
    let correo: String
    
    // Uso un constructor vacio porque no sabia como instanciar una persona "vacia" para luego cambiar su valor, esto para la persona con mayor y menor edad
    init(){
        self.nombres = ""
        self.apellidoPaterno = ""
        self.apellidoMaterno = ""
        self.fechaNacimiento = ""
        self.DNI = ""
        self.sexo = .M
        self.cantidadHermanos = 0
        self.correo = ""
    }
    
    init(nombres: String, apellidoPaterno: String, apellidoMaterno: String, fechaNacimiento: String, DNI: String, sexo: Sexo, cantidadHermanos: Int, correo: String) {
        self.nombres = nombres
        self.apellidoPaterno = apellidoPaterno
        self.apellidoMaterno = apellidoMaterno
        self.fechaNacimiento = fechaNacimiento
        self.DNI = DNI
        self.sexo = sexo
        self.cantidadHermanos = cantidadHermanos
        self.correo = correo
        
        
    }
    
    func obtenerUsuario() -> String {
        
        // Esto es para asegurarme que el @ esta en el correo y devuelve un tipo index
        guard let posArroba = self.correo.firstIndex(of: "@") else{
            return "Error - Correo Invalido"
        }
        
        // Devuelve la posicion del @ de la cadena como Int
        let posArrobaInt = posArroba.utf16Offset(in: self.correo)

        // Devuelve un substring hasta la posicion del @
        let usuario =  self.correo.prefix(posArrobaInt)
        
        return String(usuario)
    }
    
    func obtenerEdad() -> Int {
        
        // Obtenemos los valores dia, mes, año de nacimiento de la persona y almacenamos en variables
        let arrFechaNacimiento: [Int] = obtenerDiaMesAnio(fecha: self.fechaNacimiento)
        let diaNacimiento = arrFechaNacimiento[0]
        let mesNacimiento = arrFechaNacimiento[1]
        let anioNacimiento = arrFechaNacimiento[2]
        
        // Separamos los casos y hallamos la edad
        switch mesNacimiento{
            case mesHoy:
                if diaNacimiento > diaHoy {
                    return anioHoy - anioNacimiento - 1
                }else{
                    return anioHoy - anioNacimiento
                }
            case ..<mesHoy:
                return anioHoy - anioNacimiento
            default:
                return anioHoy - anioNacimiento - 1
            
        }
        
        
    }
    
    
}

// Entrada de datos - Personas
let persona1 = Persona(nombres: "CARLOS JOSÉ", apellidoPaterno: "ROBLES", apellidoMaterno: "GOMES", fechaNacimiento: "06/08/1995", DNI: "78451245", sexo: .M, cantidadHermanos: 2, correo: "carlos.roblesg@hotmail.com")

let persona2 = Persona(nombres: "MIGUEL ANGEL", apellidoPaterno: "QUISPE", apellidoMaterno: "OTERO", fechaNacimiento: "28/12/1995", DNI: "79451654", sexo: .M, cantidadHermanos: 0, correo: "miguel.anguel@gmail.com")

let persona3 = Persona(nombres: "KARLA ALEXANDRA", apellidoPaterno: "FLORES", apellidoMaterno: "ROSAS", fechaNacimiento: "15/02/1997", DNI: "77485812", sexo: .F, cantidadHermanos: 1, correo: "Karla.alexandra@hotmail.com")

let persona4 = Persona(nombres: "NICOLAS", apellidoPaterno: "QUISPE", apellidoMaterno: "ZEBALLOS", fechaNacimiento: "08/10/1990", DNI: "71748552", sexo: .M, cantidadHermanos: 1, correo: "nicolas123@gmail.com")

let persona5 = Persona(nombres: "PEDRO ANDRE", apellidoPaterno: "PICASSO", apellidoMaterno: "BETANCUR", fechaNacimiento: "17/05/1994", DNI: "74823157", sexo: .M, cantidadHermanos: 2, correo: "pedroandrepicasso@gmail.com")

let persona6 = Persona(nombres: "FABIOLA MARIA", apellidoPaterno: "PALACIO", apellidoMaterno: "VEGA", fechaNacimiento: "02/02/1992", DNI: "76758254", sexo: .F, cantidadHermanos: 0, correo: "fabi@hotmail.com")

// Almacenamos las personas en un array para recorrerlos todos
let arrPersonas : [Persona] = [persona1, persona2, persona3, persona4, persona5, persona6]



// Variables para las personas con mayor y menor edad
var personaConMayorEdad: Persona = Persona()
var personaConMenorEdad: Persona = Persona()

// Funcion para hallar la persona con mayor edad
func obtenerPersonaMayorEdad(persona: Persona){
    
    if personaConMayorEdad.DNI == "" {
        
        personaConMayorEdad = persona
        
    }else{
        
        if personaConMayorEdad.obtenerEdad() < persona.obtenerEdad(){
            
            personaConMayorEdad = persona
        }
        
    }
    
}

// Funcion para hallar la persona con menor edad
func obtenerPersonaMenorEdad(persona: Persona){
    
    if personaConMenorEdad.DNI == "" {
        
        personaConMenorEdad = persona
        
    }else{
        
        if personaConMenorEdad.obtenerEdad() > persona.obtenerEdad(){
            
            personaConMenorEdad = persona
        }
        
    }
    
}

// Variables para almacenar todos los hombres y mujeres
var arrHombres: [Persona] = []
var arrMujeres: [Persona] = []

// Funcion para rellenar los arrays de hombres y mujeres
func obtenerArraysHombresMujeres(persona: Persona){
    
    persona.sexo == .M ? arrHombres.append(persona): arrMujeres.append(persona)
    
}

// Variable para almacenar personas con mas de dos hermanos
var arrPersonasConMasDosHermanos: [Persona] = []

// Funcion para rellenar el array de las personas con mas de dos hermanos
func obtenerArrayPersonasConMasDosHermanos(persona:Persona){
    if persona.cantidadHermanos > 2 {
        arrPersonasConMasDosHermanos.append(persona)
    }
}

// Funcion para capitalizar las palabras
func capitalizar(palabra: String) -> String{
    
    // Obtenemos la primera letra de una palabra
    let primeraLetra = String(palabra.prefix(1))
    // Obtenemos el resto de la palabra y ponemos en minusculas
    let restoPalabra = String(palabra.suffix(palabra.count - 1)).lowercased()
    
    return primeraLetra+restoPalabra
    
}

func obtenerNombreCompletoPersonaFormato(persona: Persona) -> String{
    
    var nombre: String
    
    // Condicion para saber si la persona tiene dos nombres, se busca el espacio y devuelve un tipo index
    if let posEspacio = persona.nombres.firstIndex(of: " "){
        
        // Devuelve la posicion del espacio de la cadena como Int
        let posEspacio = posEspacio.utf16Offset(in: persona.nombres)

        // Devuelve un substring hasta la posicion del espacio, obteniendo el primer nombre
        nombre =  String(persona.nombres.prefix(posEspacio))
        
    } else{
        nombre = persona.nombres
    }
    
    let nombreCapitalizado = capitalizar(palabra: nombre)
    let apellidoPaternoCapitalizado = capitalizar(palabra: persona.apellidoPaterno)
    let primeraLetraApellidoMaterno = persona.apellidoMaterno.prefix(1)
    
    return nombreCapitalizado + " " + apellidoPaternoCapitalizado + " " + primeraLetraApellidoMaterno + "."
    
}

print("Lista de personas \n-----------")
for persona in arrPersonas {
    
    
    print("\(obtenerNombreCompletoPersonaFormato(persona: persona)) - DNI: \(persona.DNI) - Edad: \(persona.obtenerEdad()) - Hermanos: \(persona.cantidadHermanos) - Usuario: \(persona.obtenerUsuario())")
    
    obtenerPersonaMayorEdad(persona: persona)
    
    obtenerPersonaMenorEdad(persona: persona)
    
    obtenerArraysHombresMujeres(persona: persona)
    
    obtenerArrayPersonasConMasDosHermanos(persona: persona)
    
}

print("\nLa persona con mayor edad es: \(personaConMayorEdad.nombres) \(personaConMayorEdad.apellidoPaterno) \(personaConMayorEdad.apellidoMaterno) - Edad: \(personaConMayorEdad.obtenerEdad())")
print("La persona con menor edad es: \(personaConMenorEdad.nombres) \(personaConMenorEdad.apellidoPaterno) \(personaConMenorEdad.apellidoMaterno) - Edad: \(personaConMenorEdad.obtenerEdad())")

print("\nLista de hombres - \(arrHombres.count) \n-----------")
for hombre in arrHombres {
    print("♂︎ \(hombre.nombres) \(hombre.apellidoPaterno) \(hombre.apellidoMaterno)")
}

print("\nLista de mujeres - \(arrMujeres.count) \n-----------")
for mujeres in arrMujeres {
    print("♀︎ \(mujeres.nombres) \(mujeres.apellidoPaterno) \(mujeres.apellidoMaterno)")
}

print("\nLista de personas con mas de dos hermanos \n-----------")

if arrPersonasConMasDosHermanos.count == 0 {
    
    print("No hay personas con mas de dos hermanos")
    
}else{
    
    for persona in arrPersonasConMasDosHermanos {
        print("\(persona.nombres) \(persona.apellidoPaterno) \(persona.apellidoMaterno) - hermanos: \(persona.cantidadHermanos)")
    }

}



